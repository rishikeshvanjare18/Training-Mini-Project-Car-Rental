import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Customer } from '../customer';
import { CustomerService } from '../customerService';

@Component({
  selector: 'app-cust-list',
  templateUrl: './cust-list.component.html',
  styleUrls: ['./cust-list.component.css']
})
export class CustListComponent implements OnInit {
  x:string;
  customer: Observable<Customer[]>;
 
  constructor(private customerService: CustomerService,
    private router: Router,private route:ActivatedRoute) { }

    
  ngOnInit() {

    if(localStorage.getItem('AdminLoginStatus').match('false')){
      this.router.navigate(['/customerloginpage']);
    }

    this.reloadData();
    //console.log(localStorage.getItem('loginStatus'));
  }

  reloadData() {
    this.customer = this.customerService.getCustomersList();
  }

  deleteCustomer(id: number) {
    if(confirm("Do you really want to delete this record?")){
    this.customerService.deleteCustomer(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
      }
      this.reloadData();
  }

 customerDetails(customer_id: number){
    //this.router.navigate(['customer_details', customer_id]);
  }

  addCustomer(){
    this.router.navigate(['createCustomer']);
    this.reloadData();
  }

  updateCustomer(custid: number){
   console.log("in list id:"+custid);
    this.router.navigate(['customerupdate',custid]);
  }

  carList(){
    this.router.navigate(['Carlist']);
  }

  cartList(){
    this.router.navigate(['Cartlist']);
  }
}
