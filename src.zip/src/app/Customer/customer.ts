export class Customer {
	
	custid:number;
	mobno:number;
	username:string;
	address:string;
	name:string;
	password:string;
	email:string;
  
  active: boolean;


  }

 