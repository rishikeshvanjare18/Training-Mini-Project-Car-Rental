import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerService } from '../customerService';

@Component({
  selector: 'app-cust-login',
  templateUrl: './cust-login.component.html',
  styleUrls: ['./cust-login.component.css']
})
export class CustLoginComponent implements OnInit {

  	getData: boolean;
	model: any = {};
	user:string;
	password:string;
  constructor(private router: Router,private route: ActivatedRoute, private _httpService: CustomerService, private http: HttpClient) { }

  ngOnInit() {
  }

  loginUser() {

		//console.log(this.model.name,this.model.password);
		this.user = this.model.name;
		this.password = this.model.password;
		// console.log(user);
		// console.log(password);

		try{
		this._httpService.getAdminDetails(this.user, this.password)
			.subscribe((res: boolean) => {
				this.getData = res;
					
					
					if (this.getData == true) {
						
						alert("Login successful");
						localStorage.setItem('CustLoginStatus','true');
						//console.log("username in login:"+this.user);
						//localStorage.setItem('loginStatus', "true");
						this.goto();
						
					}
					if(localStorage.getItem('CustLoginStatus').match('false')){
						alert("login failed");
					}
					
			});

			
		}catch(error){
			alert("error");
		}
		
		
		
	}
	
	goto(){
		console.log("In goto "+this.user);

		localStorage.setItem("username",this.user);

		this.router.navigate(['/dashboard']);
	}
  
	signup(){
		this.router.navigate(['/createCustomer']);
	}

	adminlogin(){
		//console.log(this.model.name,this.model.password);
		this.user = this.model.name;
		this.password = this.model.password;

		if(this.user == "admin" && this.password == "123")
		{
			localStorage.setItem('AdminLoginStatus','true');
			this.router.navigate(['/Customerlist']);
		}
		else{
			alert("login failed");
		}
	}
	
	Logout() {
		//this.router.navigate(['/mainpage']);
	}

}
