import { Injectable } from '@angular/core';
import { HttpClient,HttpParams } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Customer } from './customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http:HttpClient,private _httpService:CustomerService) { }
  private baseUrl = 'http://localhost:8089/Customer/';

  getAdminDetails(user,password){
    
  	return this.http.get(`${this.baseUrl}`+ user +'/'+password);
    
  }

  createCustomer(customer: Object): Observable<Object> {
    return this.http.post('http://localhost:8089/post/Customer', customer);
  }

  getCustomersList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }

  
  deleteCustomer(id: number): Observable<any> {
    return this.http.get('http://localhost:8089/deleteCustomer/'+id);
  }

  updateCustomer(custid:number,customer:Object): Observable<Object>{
    return this.http.put('http://localhost:8089/update/Customer/'+custid,customer);
  }

  viewoneCustomer(custid:number):Observable<any>{
    return this.http.get(`${this.baseUrl}/${custid}`);
  }
  viewoneCustomerbyUsername(username:string):Observable<any>{
    console.log("in service "+username);
    return this.http.get('http://localhost:8089/Customer/get/'+username);
  }

}
