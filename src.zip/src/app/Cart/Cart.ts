export class Cart {
    public Cartid:number;
	public Carid:number;
	public Custid:number;


    active: boolean;

    



}
