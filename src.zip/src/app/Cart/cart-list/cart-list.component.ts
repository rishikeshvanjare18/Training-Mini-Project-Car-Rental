import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Cart } from '../Cart';
import { CartService } from '../Cart.service';

@Component({
  selector: 'app-cart-list',
  templateUrl: './cart-list.component.html',
  styleUrls: ['./cart-list.component.css']
})
export class CartListComponent implements OnInit {
  

  cart: Observable<Cart[]>;
  
  constructor(private cartService: CartService,
    private router: Router,private route:ActivatedRoute) { }

    
  ngOnInit() {

    if(!localStorage.getItem('AdminLoginStatus').match('true')){
      this.router.navigate(['/customerloginpage']);
    }

    this.reloadData();
    //console.log(localStorage.getItem('loginStatus'));
  }

  reloadData() {
    this.cart = this.cartService.getCartList();
  }

  deleteCart(cartid: number) {
    if(confirm("Do you really want to delete this record?")){
    this.cartService.deleteCart(cartid)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
      }
      this.reloadData();
      this.reloadData();
  }

  carList(){
    this.router.navigate(['Carlist']);
  }

  customerList(){
    this.router.navigate(['Customerlist']);
  }
 
}
