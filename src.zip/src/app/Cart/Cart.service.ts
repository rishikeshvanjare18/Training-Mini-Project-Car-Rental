import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

@Injectable({
    providedIn: 'root'
  })

  export class CartService {

  constructor(private http:HttpClient,private _httpService:CartService) { }
  private baseUrl = 'http://localhost:8089/Cart/';


  createCart(custid:number,carid:number): Observable<any>{
    // console.log("inside create cart"+custid+"/"+carid);
    // console.log('http://localhost:8089/post/Cart/'+custid+'/'+carid);
    return this.http.get('http://localhost:8089/post/Cart/'+custid+'/'+carid);
  }

  getCartList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }

  
  deleteCart(id: number): Observable<any> {
    return this.http.get('http://localhost:8089/deleteCart/'+id);
  }


  viewoneCart(cartId:number):Observable<any>{
    return this.http.get(`${this.baseUrl}/${cartId}`);
  }

}