import { Component, OnInit } from '@angular/core';
import { NgModel } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Car } from '../Car/Car';
import { CarService } from '../Car/CarService';
import { Cart } from '../Cart/Cart';
import { CartService } from '../Cart/Cart.service';
import { Customer } from '../Customer/customer';
import { CustomerService } from '../Customer/customerService';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  username:string;
  custid:number;
  car: Observable<Car[]>;

  cart: Cart = new Cart();

  // customer: Observable<Customer[]>
 // cartService: CartService;
  customer:Customer;
 
  car1:Car;
  constructor(private cartService: CartService,private carService: CarService,private customerService: CustomerService,
    private router: Router,private route:ActivatedRoute) { }

    
  ngOnInit() {
    if(localStorage.getItem('CustLoginStatus').match('false') ){
      this.router.navigate(['/customerloginpage']);
    }

    this.reloadData();
    //console.log(localStorage.getItem('loginStatus'));

    this.username = localStorage.getItem('username');
    console.log("in dashboard "+this.username);
    this.customerService.viewoneCustomerbyUsername(this.username)
      .subscribe(data => {
        //console.log("in the view");
       // console.log(data);
          this.custid = data;
        // console.log("inside "+this.custid);
          localStorage.setItem('custid',''+data);
      }, error => console.log(error));
              

  }

  getData(data){
    
  }

  reloadData() {
    this.car = this.carService.getCarList();
            
  }

  rentCar(carid:number){
    custid:Number;
    // console.log("inside rentcar"+carid);
    // console.log(carid);
    // localStorage.setItem('carid',''+carid);
   // this.cust = this.customer;
    //this.car. = carid;

    
    this.custid = Number(localStorage.getItem('custid'));

    localStorage.setItem('carid',''+carid);
    console.log("rentCar: custid:"+localStorage.getItem('custid'));
    console.log("rentCar: carid:"+localStorage.getItem('carid'));
    console.log(this.custid);
    // this.cart.Custid = Number(localStorage.getItem('custid'));
    // this.cart.Carid = carid;

    //this.cart.Carid = Number(localStorage.getItem('carid'));

    

    if(confirm("Do you want to rent this car")){

        this.cartService.createCart(this.custid,carid)
        .subscribe(data => console.log(data), error => console.log(error));
            

        alert("Cart Added to Rent List Successfully");
    }
  }

}
