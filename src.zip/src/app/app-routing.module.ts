import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CarListComponent } from './Car/car-list/car-list.component';
import { CreateCarComponent } from './Car/create-car/create-car.component';
import { UpdateCarComponent } from './Car/update-car/update-car.component';
import { CartListComponent } from './Cart/cart-list/cart-list.component';
import { CreateCustomerComponent } from './Customer/create-customer/create-customer.component';
import { CustListComponent } from './Customer/cust-list/cust-list.component';
import { CustLoginComponent } from './Customer/cust-login/cust-login.component';
import { UpdateCustomerComponent } from './Customer/update-customer/update-customer.component';
import { DashboardComponent } from './dashboard/dashboard.component';


const routes: Routes = [
  {path:'',redirectTo:'customerloginpage',pathMatch:'full'},
  {path:'customerloginpage', component:CustLoginComponent },
  {path:'createCustomer', component:CreateCustomerComponent },
  {path:'Customerlist', component:CustListComponent },
  {path:'customerupdate/:custid', component:UpdateCustomerComponent },

  {path:'createCar', component:CreateCarComponent},
  {path:'Carlist', component:CarListComponent },
  {path:'carupdate/:carid', component:UpdateCarComponent },


  {path:'dashboard', component:DashboardComponent },
  
  {path:'Cartlist', component:CartListComponent },


 ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
