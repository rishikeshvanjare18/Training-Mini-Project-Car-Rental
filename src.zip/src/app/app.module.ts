import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustLoginComponent } from './Customer/cust-login/cust-login.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CreateCustomerComponent } from './Customer/create-customer/create-customer.component';
import { UpdateCustomerComponent } from './Customer/update-customer/update-customer.component';

import { CustListComponent } from './Customer/cust-list/cust-list.component';
import { CreateCarComponent } from './Car/create-car/create-car.component';
import { CarListComponent } from './Car/car-list/car-list.component';
import { UpdateCarComponent } from './Car/update-car/update-car.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { NavbarComponent } from './navbar/navbar.component';
import { CartListComponent } from './Cart/cart-list/cart-list.component';

@NgModule({
  declarations: [
    AppComponent,
    CustLoginComponent,
    CreateCustomerComponent,
    UpdateCustomerComponent,
    
    CustListComponent,
    
    CreateCarComponent,
    
    CarListComponent,
    
    UpdateCarComponent,
    
    DashboardComponent,
    
    NavbarComponent,
    
    
    CartListComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
