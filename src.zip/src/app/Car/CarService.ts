import { Injectable } from '@angular/core';
import { HttpClient,HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CarService {

  constructor(private http:HttpClient,private _httpService:CarService) { }
  private baseUrl = 'http://localhost:8089/Car/';


  createCar(car: Object): Observable<Object> {
    return this.http.post('http://localhost:8089/post/Car', car);
  }

  getCarList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }

  
  deleteCar(id: number): Observable<any> {
    return this.http.get('http://localhost:8089/deleteCar/'+id);
  }

  updateCar(carId:number,car:Object): Observable<Object>{
    return this.http.put('http://localhost:8089/update/Car/'+carId,car);
  }

  viewoneCar(carId:number):Observable<any>{
    return this.http.get(`${this.baseUrl}/${carId}`);
  }

}
