import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Car } from '../Car';
import { CarService } from '../CarService';

@Component({
  selector: 'app-update-car',
  templateUrl: './update-car.component.html',
  styleUrls: ['./update-car.component.css']
})
export class UpdateCarComponent implements OnInit {
  carid: number;
  car: Car;

  constructor(private route: ActivatedRoute,private router: Router,
    private carService: CarService) { }

  ngOnInit() {

    if(localStorage.getItem('AdminLoginStatus').match('false')){
      this.router.navigate(['/customerloginpage']);
    }
    

    this.car = new Car();

    this.carid = this.route.snapshot.params['carid'];
    
    this.carService.viewoneCar(this.carid)
      .subscribe(data => {
        console.log(data)
        this.car = data;
      }, error => console.log(error));
  }
  updateCar() {
    this.carService.updateCar(this.carid,this.car)
      .subscribe(data => console.log(data), error => console.log(error));
    this.car = new Car();
    this.gotoList();
  }

  onSubmit() {
    this.updateCar();    
  }

  gotoList() {
    this.router.navigate(['/Carlist']);
  }
}
