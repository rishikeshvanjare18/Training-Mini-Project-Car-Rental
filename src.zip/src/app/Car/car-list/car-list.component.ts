import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Car } from '../Car';
import { CarService } from '../CarService';


@Component({
  selector: 'app-car-list',
  templateUrl: './car-list.component.html',
  styleUrls: ['./car-list.component.css']
})
export class CarListComponent implements OnInit {
  
  
  car: Observable<Car[]>;
  
  constructor(private carService: CarService,
    private router: Router,private route:ActivatedRoute) { }

    
  ngOnInit() {

   

    this.reloadData();
    //console.log(localStorage.getItem('loginStatus'));
  }

  reloadData() {
    this.car = this.carService.getCarList();
  }

  deleteCar(carId: number) {
    if(confirm("Do you really want to delete this record?")){
    this.carService.deleteCar(carId)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
      }
      this.reloadData();
  }

 CarDetails(carId: number){
    //this.router.navigate(['customer_details', customer_id]);
  }

  addCar(){
    this.router.navigate(['createCar']);
  }

  updateCar(carId: number){
   console.log("in list id:"+carId);
    this.router.navigate(['carupdate',carId]);
  }

  customerList(){
    this.router.navigate(['Customerlist']);
  }

  cartList(){
    this.router.navigate(['Cartlist']);
  }

}
