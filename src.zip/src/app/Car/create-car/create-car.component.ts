import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Car } from '../Car';
import { CarService } from '../CarService';

@Component({
  selector: 'app-create-car',
  templateUrl: './create-car.component.html',
  styleUrls: ['./create-car.component.css']
})
export class CreateCarComponent implements OnInit {

  car: Car = new Car();
  submitted = false;

  constructor(private carService: CarService,
    private router: Router) { }
    
    
    ngOnInit() {
      if(localStorage.getItem('AdminLoginStatus').match('false')){
        this.router.navigate(['/customerloginpage']);
      }
     
    }


    newCar(): void {
      this.car = new Car();
    }

    save() {
      this.carService.createCar(this.car)
        .subscribe(data => console.log(data), error => console.log(error));
      this.car = new Car();
      this.gotoList();
    }
  
    onSubmit() {
      this.submitted = true;
      this.save();    
    }
  
    gotoList() {
      this.router.navigate(['/Carlist']);
    }
}
