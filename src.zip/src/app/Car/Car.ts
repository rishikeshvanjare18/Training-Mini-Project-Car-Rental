export class Car {
    carid: number;
    cname: string;
    cprice: number;
    cdescription: string;
    seater: number;
    cimage: string;
    active: boolean;
}
